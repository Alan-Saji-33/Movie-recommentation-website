<?php
session_start();
define('OMDB_API_KEY', '9575487a'); // Replace with your OMDB API key
define('UNSPLASH_API_KEY', 'YOUR_UNSPLASH_API_KEY'); // Get from https://unsplash.com/developers
$conn = new mysqli('localhost', 'root', '', 'movie_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database and tables
$conn->query("CREATE DATABASE IF NOT EXISTS movie_db");
$conn->select_db('movie_db');

$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    username VARCHAR(50),
    preferences TEXT,
    is_admin TINYINT(1) DEFAULT 0,
    is_banned TINYINT(1) DEFAULT 0,
    profile_picture TEXT
)");

$conn->query("CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    imdb_id VARCHAR(50),
    rating INT,
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved TINYINT(1) DEFAULT 0,
    admin_comment TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
)");

$conn->query("CREATE TABLE IF NOT EXISTS movies (
    imdb_id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255),
    year VARCHAR(4),
    poster TEXT,
    plot TEXT,
    genre VARCHAR(255),
    director VARCHAR(255),
    actors VARCHAR(255),
    runtime VARCHAR(50),
    imdb_rating VARCHAR(10),
    awards TEXT,
    box_office TEXT,
    language VARCHAR(255),
    country VARCHAR(255),
    release_date VARCHAR(50)
)");

$conn->query("CREATE TABLE IF NOT EXISTS watchlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    imdb_id VARCHAR(50),
    notes TEXT,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)");

$conn->query("CREATE TABLE IF NOT EXISTS recently_viewed (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    imdb_id VARCHAR(50),
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)");

$conn->query("CREATE TABLE IF NOT EXISTS followers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    follower_id INT,
    followed_id INT,
    FOREIGN KEY (follower_id) REFERENCES users(id),
    FOREIGN KEY (followed_id) REFERENCES users(id)
)");

$conn->query("CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)");

// CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
