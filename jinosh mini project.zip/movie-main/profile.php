<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();
$reviews = $conn->query("SELECT r.*, m.title FROM reviews r JOIN movies m ON r.imdb_id = m.imdb_id WHERE r.user_id=$user_id AND r.approved=1 ORDER BY r.created_at DESC");
$watchlist = $conn->query("SELECT m.* FROM watchlist w JOIN movies m ON w.imdb_id = m.imdb_id WHERE w.user_id=$user_id");
$recently_viewed = $conn->query("SELECT m.* FROM recently_viewed rv JOIN movies m ON rv.imdb_id = m.imdb_id WHERE rv.user_id=$user_id ORDER BY rv.viewed_at DESC LIMIT 5");
$followers = $conn->query("SELECT u.username, u.email FROM followers f JOIN users u ON f.followed_id = u.id WHERE f.follower_id=$user_id");
$following = $conn->query("SELECT u.username, u.email FROM followers f JOIN users u ON f.follower_id = u.id WHERE f.followed_id=$user_id");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    if ($_POST['action'] === 'update_profile') {
        $username = $_POST['username'];
        $preferences = json_encode($_POST['genres'] ?? []);
        $stmt = $conn->prepare("UPDATE users SET username=?, preferences=? WHERE id=?");
        $stmt->bind_param("ssi", $username, $preferences, $user_id);
        $stmt->execute();
        header("Location: profile.php");
        exit;
    }
}
$genres = ['Action', 'Comedy', 'Drama', 'Sci-Fi', 'Romance', 'Thriller', 'Horror', 'Adventure', 'Fantasy', 'Animation'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - MovieFlix</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🎥 MovieFlix</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="watchlist.php">Watchlist</a>
            <?php if ($_SESSION['is_admin']): ?>
                <a href="admin.php">Admin Dashboard</a>
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <section class="profile">
        <h2><?php echo htmlspecialchars($user['username'] ?? $user['email']); ?>'s Profile</h2>
        <form method="POST" class="profile-form">
            <input type="hidden" name="action" value="update_profile">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <label>Username:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" required>
            <label>Preferred Genres:</label>
            <div class="genre-checkboxes">
                <?php foreach ($genres as $genre): ?>
                    <label><input type="checkbox" name="genres[]" value="<?php echo $genre; ?>" <?php echo in_array($genre, json_decode($user['preferences'] ?? '[]', true)) ? 'checked' : ''; ?>> <?php echo $genre; ?></label>
                <?php endforeach; ?>
            </div>
            <button type="submit">Update Profile</button>
        </form>
        <h3>Your Reviews</h3>
        <div class="reviews">
            <?php while ($review = $reviews->fetch_assoc()): ?>
                <div class="review">
                    <p><strong><?php echo htmlspecialchars($review['title']); ?> (<?php echo $review['rating']; ?> ★):</strong> <?php echo htmlspecialchars($review['review_text']); ?></p>
                    <p><small><?php echo $review['created_at']; ?></small></p>
                </div>
            <?php endwhile; ?>
        </div>
        <h3>Recently Viewed</h3>
        <div class="movies-grid">
            <?php while ($movie = $recently_viewed->fetch_assoc()): ?>
                <div class="movie">
                    <img src="<?php echo htmlspecialchars($movie['poster']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                    <div class="movie-info">
                        <div class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></div>
                        <div class="movie-year"><?php echo htmlspecialchars($movie['year']); ?></div>
                        <a href="movie.php?id=<?php echo htmlspecialchars($movie['imdb_id']); ?>" class="view-btn">View Details</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <h3>Followers</h3>
        <div class="followers">
            <?php while ($follower = $followers->fetch_assoc()): ?>
                <p><?php echo htmlspecialchars($follower['username'] ?? $follower['email']); ?></p>
            <?php endwhile; ?>
        </div>
        <h3>Following</h3>
        <div class="following">
            <?php while ($followed = $following->fetch_assoc()): ?>
                <p><?php echo htmlspecialchars($followed['username'] ?? $followed['email']); ?></p>
            <?php endwhile; ?>
        </div>
    </section>
</body>
</html>
