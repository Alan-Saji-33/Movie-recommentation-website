<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$watchlist = $conn->query("SELECT m.*, w.notes FROM watchlist w JOIN movies m ON w.imdb_id = m.imdb_id WHERE w.user_id=$user_id ORDER BY w.added_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Watchlist - MovieFlix</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🎥 MovieFlix</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="profile.php">Profile</a>
            <?php if ($_SESSION['is_admin']): ?>
                <a href="admin.php">Admin Dashboard</a>
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <section class="watchlist">
        <h2>My Watchlist</h2>
        <div class="movies-grid">
            <?php while ($movie = $watchlist->fetch_assoc()): ?>
                <div class="movie">
                    <img src="<?php echo htmlspecialchars($movie['poster']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                    <div class="movie-info">
                        <div class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></div>
                        <div class="movie-year"><?php echo htmlspecialchars($movie['year']); ?></div>
                        <?php if ($movie['notes']): ?>
                            <p><strong>Notes:</strong> <?php echo htmlspecialchars($movie['notes']); ?></p>
                        <?php endif; ?>
                        <a href="movie.php?id=<?php echo htmlspecialchars($movie['imdb_id']); ?>" class="view-btn">View Details</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
</body>
</html>
