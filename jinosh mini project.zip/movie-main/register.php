<?php
require 'config.php';
$genres = ['Action', 'Comedy', 'Drama', 'Sci-Fi', 'Romance', 'Thriller', 'Horror', 'Adventure', 'Fantasy', 'Animation'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $preferences = json_encode($_POST['genres'] ?? []);
    $stmt = $conn->prepare("INSERT INTO users (email, username, password, preferences) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $email, $username, $password, $preferences);
    if ($stmt->execute()) {
        header("Location: login.php");
        exit;
    } else {
        $error = "Email already exists";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - MovieFlix</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <h2>Join MovieFlix</h2>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="input-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                <div class="input-group">
                    <input type="text" name="username" placeholder="Username" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <label>Select Preferred Genres:</label>
                <div class="genre-checkboxes">
                    <?php foreach ($genres as $genre): ?>
                        <label><input type="checkbox" name="genres[]" value="<?php echo $genre; ?>"> <?php echo $genre; ?></label>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="auth-btn">Register</button>
            </form>
            <div class="social-login">
                <button class="social-btn google">Sign up with Google</button>
                <button class="social-btn facebook">Sign up with Facebook</button>
            </div>
            <p>Already have an account? <a href="login.php">Login</a></p>
            <p><a href="index.php">Back to Home</a></p>
        </div>
    </div>
</body>
</html>
