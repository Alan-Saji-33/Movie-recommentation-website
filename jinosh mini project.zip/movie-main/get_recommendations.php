<?php
require 'config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT preferences FROM users WHERE id=$user_id")->fetch_assoc();
$preferences = json_decode($user['preferences'] ?? '[]', true);
$genres = !empty($preferences) ? $preferences : ['Action', 'Comedy', 'Drama'];

// Fetch recently viewed genres
$recent_genres = $conn->query("SELECT DISTINCT m.genre FROM recently_viewed rv JOIN movies m ON rv.imdb_id = m.imdb_id WHERE rv.user_id=$user_id");
while ($row = $recent_genres->fetch_assoc()) {
    $genres = array_merge($genres, explode(', ', $row['genre']));
}
$genres = array_unique($genres);

$movies = [];
foreach ($genres as $genre) {
    $url = "http://www.omdbapi.com/?apikey=" . OMDB_API_KEY . "&s=" . urlencode($genre) . "&y=2024";
    $data = json_decode(file_get_contents($url), true);
    if ($data['Response'] === 'True') {
        foreach ($data['Search'] as $movie) {
            $movie['Poster'] = $movie['Poster'] === 'N/A' ? fetchUnsplashImage($movie['Title']) : $movie['Poster'];
            $movies[] = $movie;
        }
    }
}

echo json_encode(array_slice(array_unique($movies, SORT_REGULAR), 0, 6));

function fetchUnsplashImage($query) {
    $url = "https://api.unsplash.com/search/photos?query=" . urlencode($query . " movie") . "&client_id=" . UNSPLASH_API_KEY;
    $data = json_decode(file_get_contents($url), true);
    return $data['results'][0]['urls']['regular'] ?? 'https://via.placeholder.com/300x450?text=No+Image';
}
?>
