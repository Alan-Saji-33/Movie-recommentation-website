<?php
require 'config.php';
$imdb_id = $_GET['id'] ?? '';
if (!$imdb_id) die("Invalid movie ID");

// Fetch movie from database or OMDB API
$movie = $conn->query("SELECT * FROM movies WHERE imdb_id='$imdb_id'")->fetch_assoc();
if (!$movie) {
    $url = "http://www.omdbapi.com/?apikey=" . OMDB_API_KEY . "&i=$imdb_id";
    $data = json_decode(file_get_contents($url), true);
    if ($data['Response'] === 'True') {
        $poster = $data['Poster'] === 'N/A' ? fetchUnsplashImage($data['Title']) : $data['Poster'];
        $stmt = $conn->prepare("INSERT INTO movies (imdb_id, title, year, poster, plot, genre, director, actors, runtime, imdb_rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "ssssssssss",
            $data['imdbID'],
            $data['Title'],
            $data['Year'],
            $poster,
            $data['Plot'],
            $data['Genre'],
            $data['Director'],
            $data['Actors'],
            $data['Runtime'],
            $data['imdbRating']
        );
        $stmt->execute();
        $movie = [
            'imdb_id' => $data['imdbID'],
            'title' => $data['Title'],
            'year' => $data['Year'],
            'poster' => $poster,
            'plot' => $data['Plot'],
            'genre' => $data['Genre'],
            'director' => $data['Director'],
            'actors' => $data['Actors'],
            'runtime' => $data['Runtime'],
            'imdb_rating' => $data['imdbRating']
        ];
    } else {
        die("Movie not found");
    }
}

// Fetch reviews and average rating
$reviews = $conn->query("SELECT r.*, u.email FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.imdb_id='$imdb_id' AND r.approved=1 ORDER BY r.created_at DESC");
$avg_rating = $conn->query("SELECT AVG(rating) as avg FROM reviews WHERE imdb_id='$imdb_id' AND approved=1")->fetch_assoc()['avg'];

// Check if movie is in user's watchlist
$is_in_watchlist = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $is_in_watchlist = $conn->query("SELECT * FROM watchlist WHERE user_id=$user_id AND imdb_id='$imdb_id'")->num_rows > 0;
}

// Handle watchlist addition/removal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    if ($_POST['action'] === 'toggle_watchlist' && isset($_SESSION['user_id'])) {
        if ($is_in_watchlist) {
            $conn->query("DELETE FROM watchlist WHERE user_id=$user_id AND imdb_id='$imdb_id'");
        } else {
            $stmt = $conn->prepare("INSERT INTO watchlist (user_id, imdb_id) VALUES (?, ?)");
            $stmt->bind_param("is", $user_id, $imdb_id);
            $stmt->execute();
        }
        header("Location: movie.php?id=$imdb_id");
        exit;
    } elseif ($_POST['action'] === 'submit_review' && isset($_SESSION['user_id'])) {
        $rating = $_POST['star'] ?? '';
        $review_text = $_POST['reviewText'] ?? '';
        if ($rating && $review_text) {
            $stmt = $conn->prepare("INSERT INTO reviews (user_id, imdb_id, rating, review_text, approved) VALUES (?, ?, ?, ?, 1)");
            $stmt->bind_param("isis", $user_id, $imdb_id, $rating, $review_text);
            $stmt->execute();
            header("Location: movie.php?id=$imdb_id");
            exit;
        }
    }
}

// Unsplash image fallback function
function fetchUnsplashImage($query) {
    $url = "https://api.unsplash.com/search/photos?query=" . urlencode($query) . "&client_id=" . UNSPLASH_API_KEY;
    $data = json_decode(file_get_contents($url), true);
    return $data['results'][0]['urls']['regular'] ?? 'https://via.placeholder.com/300x450?text=No+Image';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($movie['title'] ?? 'Movie'); ?> - MovieFlix</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🎥 MovieFlix</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="watchlist.php">Watchlist</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
                <?php if ($_SESSION['is_admin']): ?>
                    <a href="admin.php">Admin Dashboard</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </header>
    <div class="movie-details">
        <img src="<?php echo htmlspecialchars($movie['poster']); ?>" alt="<?php echo htmlspecialchars($movie['title'] ?? 'Movie'); ?>">
        <div class="movie-info">
            <h1><?php echo htmlspecialchars($movie['title'] ?? 'Unknown Title'); ?> (<?php echo htmlspecialchars($movie['year'] ?? 'N/A'); ?>)</h1>
            <p><strong>Genre:</strong> <?php echo htmlspecialchars($movie['genre'] ?? 'N/A'); ?></p>
            <p><strong>Director:</strong> <?php echo htmlspecialchars($movie['director'] ?? 'N/A'); ?></p>
            <p><strong>Actors:</strong> <?php echo htmlspecialchars($movie['actors'] ?? 'N/A'); ?></p>
            <p><strong>Runtime:</strong> <?php echo htmlspecialchars($movie['runtime'] ?? 'N/A'); ?></p>
            <p><strong>IMDb Rating:</strong> <?php echo htmlspecialchars($movie['imdb_rating'] ?? 'N/A'); ?> / 10</p>
            <p><strong>Average User Rating:</strong> <?php echo $avg_rating ? round($avg_rating, 1) : 'N/A'; ?> ★</p>
            <p><strong>Plot:</strong> <?php echo htmlspecialchars($movie['plot'] ?? 'No plot available'); ?></p>
            <div class="movie-actions">
                <a href="https://www.youtube.com/results?search_query=<?php echo urlencode($movie['title'] . ' trailer'); ?>" target="_blank" class="trailer-btn">Watch Trailer</a>
                <form method="POST">
                    <input type="hidden" name="action" value="toggle_watchlist">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <button type="submit" class="watchlist-btn"><?php echo $is_in_watchlist ? 'Remove from Watchlist' : 'Add to Watchlist'; ?></button>
                </form>
                <div class="social-share">
                    <a href="https://twitter.com/intent/tweet?text=Check out <?php echo urlencode($movie['title']); ?> on MovieFlix!&url=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . '/movie.php?id=' . $imdb_id); ?>" target="_blank">Share on Twitter</a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . '/movie.php?id=' . $imdb_id); ?>" target="_blank">Share on Facebook</a>
                </div>
            </div>
            <div class="ott-links">
                <h3>Watch on:</h3>
                <a href="https://www.netflix.com" target="_blank">Netflix</a>
                <a href="https://www.amazon.com/Prime-Video" target="_blank">Amazon Prime</a>
                <a href="https://www.disneyplus.com" target="_blank">Disney+</a>
                <a href="https://www.hulu.com" target="_blank">Hulu</a>
            </div>
        </div>
    </div>
    <div class="reviews-section">
        <h2>User Reviews</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <form id="reviewForm" method="POST">
                <input type="hidden" name="action" value="submit_review">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <label>Rate this movie:</label>
                <div class="rating">
                    <input type="radio" name="star" id="star5" value="5"><label for="star5">★</label>
                    <input type="radio" name="star" id="star4" value="4"><label for="star4">★</label>
                    <input type="radio" name="star" id="star3" value="3"><label for="star3">★</label>
                    <input type="radio" name="star" id="star2" value="2"><label for="star2">★</label>
                    <input type="radio" name="star" id="star1" value="1"><label for="star1">★</label>
                </div>
                <textarea name="reviewText" placeholder="Write your review..." required></textarea>
                <button type="submit">Submit Review</button>
            </form>
        <?php else: ?>
            <p><a href="login.php">Login</a> to submit a review.</p>
        <?php endif; ?>
        <div id="reviewDisplay">
            <?php while ($review = $reviews->fetch_assoc()): ?>
                <div class="review">
                    <p><strong><?php echo htmlspecialchars($review['email']); ?> (<?php echo htmlspecialchars($review['rating']); ?> ★):</strong> <?php echo htmlspecialchars($review['review_text']); ?></p>
                    <p><small><?php echo htmlspecialchars($review['created_at']); ?></small></p>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
