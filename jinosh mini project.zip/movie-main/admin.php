<?php
require 'config.php';
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    if ($_POST['action'] === 'add_movie') {
        $imdb_id = $_POST['imdb_id'];
        $url = "http://www.omdbapi.com/?apikey=" . OMDB_API_KEY . "&i=$imdb_id";
        $data = json_decode(file_get_contents($url), true);
        if ($data['Response'] === 'True') {
            $poster = $data['Poster'] === 'N/A' ? fetchUnsplashImage($data['Title']) : $data['Poster'];
            $stmt = $conn->prepare("INSERT INTO movies (imdb_id, title, year, poster, plot, genre, director, actors, runtime, imdb_rating, awards, box_office, language, country, release_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param(
                "sssssssssssssss",
                $data['imdbID'],
                $data['Title'],
                $data['Year'],
                $poster,
                $data['Plot'],
                $data['Genre'],
                $data['Director'],
                $data['Actors'],
                $data['Runtime'],
                $data['imdbRating'],
                $data['Awards'],
                $data['BoxOffice'],
                $data['Language'],
                $data['Country'],
                $data['Released']
            );
            $stmt->execute();
        }
    } elseif ($_POST['action'] === 'add_custom_movie') {
        $movie = [
            'imdb_id' => 'custom_' . uniqid(),
            'title' => $_POST['title'],
            'year' => $_POST['year'],
            'poster' => $_POST['poster'] ?: fetchUnsplashImage($_POST['title']),
            'plot' => $_POST['plot'],
            'genre' => $_POST['genre'],
            'director' => $_POST['director'],
            'actors' => $_POST['actors'],
            'runtime' => $_POST['runtime'],
            'imdb_rating' => $_POST['imdb_rating'],
            'awards' => $_POST['awards'],
            'box_office' => $_POST['box_office'],
            'language' => $_POST['language'],
            'country' => $_POST['country'],
            'release_date' => $_POST['release_date']
        ];
        $stmt = $conn->prepare("INSERT INTO movies (imdb_id, title, year, poster, plot, genre, director, actors, runtime, imdb_rating, awards, box_office, language, country, release_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "sssssssssssssss",
            $movie['imdb_id'],
            $movie['title'],
            $movie['year'],
            $movie['poster'],
            $movie['plot'],
            $movie['genre'],
            $movie['director'],
            $movie['actors'],
            $movie['runtime'],
            $movie['imdb_rating'],
            $movie['awards'],
            $movie['box_office'],
            $movie['language'],
            $movie['country'],
            $movie['release_date']
        );
        $stmt->execute();
    } elseif ($_POST['action'] === 'bulk_import') {
        $genre = $_POST['genre'];
        $year = $_POST['year'];
        $url = "http://www.omdbapi.com/?apikey=" . OMDB_API_KEY . "&s=" . urlencode($genre) . "&y=$year";
        $data = json_decode(file_get_contents($url), true);
        if ($data['Response'] === 'True') {
            foreach ($data['Search'] as $movie) {
                $details = json_decode(file_get_contents("http://www.omdbapi.com/?apikey=" . OMDB_API_KEY . "&i=" . $movie['imdbID']), true);
                if ($details['Response'] === 'True') {
                    $poster = $details['Poster'] === 'N/A' ? fetchUnsplashImage($details['Title']) : $details['Poster'];
                    $stmt = $conn->prepare("INSERT IGNORE INTO movies (imdb_id, title, year, poster, plot, genre, director, actors, runtime, imdb_rating, awards, box_office, language, country, release_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param(
                        "sssssssssssssss",
                        $details['imdbID'],
                        $details['Title'],
                        $details['Year'],
                        $poster,
                        $details['Plot'],
                        $details['Genre'],
                        $details['Director'],
                        $details['Actors'],
                        $details['Runtime'],
                        $details['imdbRating'],
                        $details['Awards'],
                        $details['BoxOffice'],
                        $details['Language'],
                        $details['Country'],
                        $details['Released']
                    );
                    $stmt->execute();
                }
            }
        }
    } elseif ($_POST['action'] === 'delete_movie') {
        $imdb_id = $_POST['imdb_id'];
        $conn->query("DELETE FROM movies WHERE imdb_id='$imdb_id'");
        $conn->query("DELETE FROM reviews WHERE imdb_id='$imdb_id'");
        $conn->query("DELETE FROM watchlist WHERE imdb_id='$imdb_id'");
        $conn->query("DELETE FROM recently_viewed WHERE imdb_id='$imdb_id'");
    } elseif ($_POST['action'] === 'toggle_review') {
        $review_id = $_POST['review_id'];
        $approved = $_POST['approved'] ? 0 : 1;
        $admin_comment = $_POST['admin_comment'] ?? '';
        $stmt = $conn->prepare("UPDATE reviews SET approved=?, admin_comment=? WHERE id=?");
        $stmt->bind_param("isi", $approved, $admin_comment, $review_id);
        $stmt->execute();
        if ($approved) {
            $review = $conn->query("SELECT user_id FROM reviews WHERE id=$review_id")->fetch_assoc();
            $conn->query("INSERT INTO notifications (user_id, message) VALUES ({$review['user_id']}, 'Your review has been approved.')");
        }
    } elseif ($_POST['action'] === 'delete_review') {
        $review_id = $_POST['review_id'];
        $conn->query("DELETE FROM reviews WHERE id='$review_id'");
    } elseif ($_POST['action'] === 'manage_user') {
        $user_id = $_POST['user_id'];
        if ($_POST['sub_action'] === 'ban') {
            $conn->query("UPDATE users SET is_banned=1 WHERE id=$user_id");
        } elseif ($_POST['sub_action'] === 'unban') {
            $conn->query("UPDATE users SET is_banned=0 WHERE id=$user_id");
        } elseif ($_POST['sub_action'] === 'promote') {
            $conn->query("UPDATE users SET is_admin=1 WHERE id=$user_id");
        }
    }
}

$movies = $conn->query("SELECT * FROM movies ORDER BY title");
$reviews = $conn->query("SELECT r.*, m.title, u.email, u.username FROM reviews r JOIN movies m ON r.imdb_id = m.imdb_id JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
$users = $conn->query("SELECT * FROM users ORDER BY email");
$genres = ['Action', 'Comedy', 'Drama', 'Sci-Fi', 'Romance', 'Thriller', 'Horror', 'Adventure', 'Fantasy', 'Animation'];
$stats = [
    'total_movies' => $conn->query("SELECT COUNT(*) as count FROM movies")->fetch_assoc()['count'],
    'total_users' => $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'],
    'total_reviews' => $conn->query("SELECT COUNT(*) as count FROM reviews")->fetch_assoc()['count'],
    'popular_movies' => $conn->query("SELECT m.title, COUNT(rv.id) as views FROM recently_viewed rv JOIN movies m ON rv.imdb_id = m.imdb_id GROUP BY rv.imdb_id ORDER BY views DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC)
];

function fetchUnsplashImage($query) {
    $url = "https://api.unsplash.com/search/photos?query=" . urlencode($query . " movie") . "&client_id=" . UNSPLASH_API_KEY;
    $data = json_decode(file_get_contents($url), true);
    return $data['results'][0]['urls']['regular'] ?? 'https://via.placeholder.com/300x450?text=No+Image';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - MovieFlix</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🎥 MovieFlix</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <div class="admin-dashboard">
        <h2>Admin Dashboard</h2>
        <section class="analytics">
            <h3>Site Analytics</h3>
            <p>Total Movies: <?php echo $stats['total_movies']; ?></p>
            <p>Total Users: <?php echo $stats['total_users']; ?></p>
            <p>Total Reviews: <?php echo $stats['total_reviews']; ?></p>
            <h4>Most Viewed Movies</h4>
            <ul>
                <?php foreach ($stats['popular_movies'] as $movie): ?>
                    <li><?php echo htmlspecialchars($movie['title']); ?> (<?php echo $movie['views']; ?> views)</li>
                <?php endforeach; ?>
            </ul>
        </section>
        <h3>Add Movie via IMDb ID</h3>
        <form method="POST" class="admin-form">
            <input type="hidden" name="action" value="add_movie">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="text" name="imdb_id" placeholder="Enter IMDb ID (e.g., tt1234567)" required>
            <button type="submit">Add Movie</button>
        </form>
        <h3>Add Custom Movie</h3>
        <form method="POST" class="admin-form">
            <input type="hidden" name="action" value="add_custom_movie">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="text" name="title" placeholder="Title" required>
            <input type="text" name="year" placeholder="Year" required>
            <input type="text" name="poster" placeholder="Poster URL (optional)">
            <textarea name="plot" placeholder="Plot" required></textarea>
            <input type="text" name="genre" placeholder="Genre" required>
            <input type="text" name="director" placeholder="Director" required>
            <input type="text" name="actors" placeholder="Actors" required>
            <input type="text" name="runtime" placeholder="Runtime" required>
            <input type="text" name="imdb_rating" placeholder="IMDb Rating" required>
            <input type="text" name="awards" placeholder="Awards">
            <input type="text" name="box_office" placeholder="Box Office">
            <input type="text" name="language" placeholder="Language">
            <input type="text" name="country" placeholder="Country">
            <input type="text" name="release_date" placeholder="Release Date">
            <button type="submit">Add Custom Movie</button>
        </form>
        <h3>Bulk Import Movies</h3>
        <form method="POST" class="admin-form">
            <input type="hidden" name="action" value="bulk_import">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <select name="genre" required>
                <option value="">Select Genre</option>
                <?php foreach ($genres as $genre): ?>
                    <option value="<?php echo $genre; ?>"><?php echo $genre; ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" name="year" placeholder="Year (e.g., 2024)" required>
            <button type="submit">Import Movies</button>
        </form>
        <h3>Manage Movies</h3>
        <table>
            <tr><th>Title</th><th>Year</th><th>Action</th></tr>
            <?php while ($movie = $movies->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($movie['title']); ?></td>
                    <td><?php echo htmlspecialchars($movie['year']); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="delete_movie">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="imdb_id" value="<?php echo $movie['imdb_id']; ?>">
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
        <h3>Manage Reviews</h3>
        <table>
            <tr><th>Movie</th><th>User</th><th>Rating</th><th>Review</th><th>Status</th><th>Admin Comment</th><th>Action</th></tr>
            <?php while ($review = $reviews->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($review['title']); ?></td>
                    <td><?php echo htmlspecialchars($review['username'] ?? $review['email']); ?></td>
                    <td><?php echo htmlspecialchars($review['rating']); ?> ★</td>
                    <td><?php echo htmlspecialchars($review['review_text']); ?></td>
                    <td><?php echo $review['approved'] ? 'Approved' : 'Pending'; ?></td>
                    <td><?php echo htmlspecialchars($review['admin_comment'] ?? 'N/A'); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="toggle_review">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                            <input type="hidden" name="approved" value="<?php echo $review['approved']; ?>">
                            <input type="text" name="admin_comment" placeholder="Admin comment">
                            <button type="submit"><?php echo $review['approved'] ? 'Unapprove' : 'Approve'; ?></button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="delete_review">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
        <h3>Manage Users</h3>
        <table>
            <tr><th>Email</th><th>Username</th><th>Status</th><th>Action</th></tr>
            <?php while ($user = $users->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></td>
                    <td><?php echo $user['is_banned'] ? 'Banned' : ($user['is_admin'] ? 'Admin' : 'Active'); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="manage_user">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <input type="hidden" name="sub_action" value="<?php echo $user['is_banned'] ? 'unban' : 'ban'; ?>">
                            <button type="submit"><?php echo $user['is_banned'] ? 'Unban' : 'Ban'; ?></button>
                        </form>
                        <?php if (!$user['is_admin']): ?>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="manage_user">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <input type="hidden" name="sub_action" value="promote">
                                <button type="submit">Promote to Admin</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
