<?php
require 'config.php';

// Define genres and sort options
$genres = ['Action', 'Comedy', 'Drama', 'Sci-Fi', 'Romance', 'Thriller', 'Horror', 'Adventure', 'Fantasy', 'Animation'];
$sort_options = [
    'year_desc' => 'Newest',
    'year_asc' => 'Oldest',
    'rating_desc' => 'Highest Rated',
    'popularity' => 'Popular'
];

// Get filter values from GET parameters
$selected_genre = isset($_GET['genre']) ? $_GET['genre'] : '';
$selected_sort = isset($_GET['sort']) ? $_GET['sort'] : 'year_desc';

// Fetch notifications for logged-in users
$notifications = null;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $notifications = $conn->query("SELECT * FROM notifications WHERE user_id=$user_id ORDER BY created_at DESC LIMIT 5");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MovieFlix - Discover Movies</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🎥 MovieFlix</div>
        <nav>
            <a href="index.php">Home</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="watchlist.php">Watchlist</a>
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                    <a href="admin.php">Admin Dashboard</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
        <div class="search-box">
            <input id="searchInput" type="text" placeholder="Search movies or series...">
        </div>
    </header>

    <section class="hero">
        <div class="carousel" id="carousel"></div>
    </section>

    <?php if ($notifications && $notifications->num_rows > 0): ?>
        <section class="notifications">
            <h2>Notifications</h2>
            <div class="notification-list">
                <?php while ($notif = $notifications->fetch_assoc()): ?>
                    <p><?php echo htmlspecialchars($notif['message']); ?> <small><?php echo htmlspecialchars($notif['created_at']); ?></small></p>
                <?php endwhile; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="filters">
        <select id="genreFilter">
            <option value="">All Genres</option>
            <?php foreach ($genres as $genre): ?>
                <option value="<?php echo htmlspecialchars($genre); ?>" <?php echo $selected_genre === $genre ? 'selected' : ''; ?>><?php echo htmlspecialchars($genre); ?></option>
            <?php endforeach; ?>
        </select>
        <select id="sortFilter">
            <?php foreach ($sort_options as $key => $label): ?>
                <option value="<?php echo htmlspecialchars($key); ?>" <?php echo $selected_sort === $key ? 'selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
            <?php endforeach; ?>
        </select>
    </section>

    <section class="recommendations">
        <h2>Recommended for You</h2>
        <div id="recommendedMovies" class="movies-grid"></div>
    </section>

    <section class="movies">
        <h2>Explore Movies</h2>
        <div id="movies" class="movies-grid"></div>
    </section>

    <div id="error" class="error"></div>

    <script src="script.js"></script>
</body>
</html>