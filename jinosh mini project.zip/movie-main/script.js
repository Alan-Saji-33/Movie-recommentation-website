const OMDB_API_KEY = '9575487a';
const container = document.getElementById('movies');
const recommendedContainer = document.getElementById('recommendedMovies');
const errorDiv = document.getElementById('error');
const searchInput = document.getElementById('searchInput');
const genreFilter = document.getElementById('genreFilter');
const sortFilter = document.getElementById('sortFilter');
const carousel = document.getElementById('carousel');
const recentYears = [2025, 2024, 2023];
const popularTerms = ['action', 'thriller', 'romance', 'comedy', 'sci-fi', 'drama'];
const usedTitles = new Set();

async function fetchMovies(term, year = '', genre = '') {
    const url = `http://www.omdbapi.com/?apikey=${OMDB_API_KEY}&s=${encodeURIComponent(term)}${year ? `&y=${year}` : ''}`;
    try {
        errorDiv.innerText = 'Loading...';
        const res = await fetch(url);
        const data = await res.json();
        errorDiv.innerText = '';
        if (data.Response === 'True') {
            return genre ? data.Search.filter(movie => movie.Type === 'movie' && movie.Genre?.toLowerCase().includes(genre.toLowerCase())) : data.Search;
        }
        return [];
    } catch (err) {
        errorDiv.innerText = 'Failed to fetch movies.';
        return [];
    }
}

function renderMovie(movie, container) {
    const div = document.createElement('div');
    div.className = 'movie';
    div.innerHTML = `
        <img src="${movie.Poster || 'https://via.placeholder.com/200x300?text=No+Image'}" alt="${movie.Title}">
        <div class="movie-info">
            <div class="movie-title">${movie.Title}</div>
            <div class="movie-year">${movie.Year}</div>
            <a href="movie.php?id=${movie.imdbID}" class="view-btn">View Details</a>
        </div>
    `;
    container.appendChild(div);
}

function clearMovies(container) {
    container.innerHTML = '';
    usedTitles.clear();
}

async function loadCarousel() {
    if (!carousel) return;
    const movies = await fetchMovies('popular', '2024');
    movies.slice(0, 3).forEach(movie => {
        const div = document.createElement('div');
        div.className = 'carousel-item';
        div.style.backgroundImage = `url(${movie.Poster || 'https://via.placeholder.com/1200x500?text=No+Image'})`;
        div.innerHTML = `<h2>${movie.Title}</h2>`;
        carousel.appendChild(div);
    });
    let index = 0;
    setInterval(() => {
        index = (index + 1) % carousel.children.length;
        carousel.style.transform = `translateX(-${index * 100}%)`;
    }, 5000);
}

async function loadRecommendations() {
    if (!recommendedContainer) return;
    clearMovies(recommendedContainer);
    try {
        const response = await fetch('get_recommendations.php');
        const movies = await response.json();
        if (movies.length === 0) {
            errorDiv.innerText = 'No recommendations available.';
        } else {
            movies.forEach(movie => renderMovie(movie, recommendedContainer));
        }
    } catch (err) {
        errorDiv.innerText = 'Failed to load recommendations.';
    }
}

async function loadMovies(genre = '', sort = 'year_desc') {
    if (!container) return;
    clearMovies(container);
    let movies = [];
    for (let year of recentYears) {
        for (let term of popularTerms) {
            const results = await fetchMovies(term, year, genre);
            movies = movies.concat(results);
        }
    }
    movies = [...new Set(movies.map(m => m.imdbID))].map(id => movies.find(m => m.imdbID === id));
    if (sort === 'year_desc') movies.sort((a, b) => b.Year - a.Year);
    if (sort === 'year_asc') movies.sort((a, b) => a.Year - b.Year);
    if (sort === 'rating_desc') movies.sort((a, b) => (b.imdbRating || 0) - (a.imdbRating || 0));
    if (sort === 'popularity') movies.sort(() => Math.random() - 0.5); // Simulate popularity
    movies.forEach(movie => {
        if (!usedTitles.has(movie.imdbID)) {
            usedTitles.add(movie.imdbID);
            renderMovie(movie, container);
        }
    });
    if (movies.length === 0) {
        errorDiv.innerText = 'No movies found.';
    }
}

let searchTimeout;
function debounce(func, wait) {
    return function (...args) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => func.apply(this, args), wait);
    };
}

async function handleSearch() {
    const term = searchInput.value.trim();
    const genre = genreFilter ? genreFilter.value : '';
    const sort = sortFilter ? sortFilter.value : 'year_desc';
    if (!term) return loadMovies(genre, sort);
    clearMovies(container);
    const movies = await fetchMovies(term, '', genre);
    if (movies.length === 0) {
        errorDiv.innerText = 'No movies found.';
    } else {
        errorDiv.innerText = '';
        movies.forEach(movie => renderMovie(movie, container));
    }
}

if (searchInput) {
    searchInput.addEventListener('input', debounce(() => {
        if (searchInput.value.length > 3 || searchInput.value.length === 0) {
            handleSearch();
        }
    }, 500));
}

if (genreFilter) {
    genreFilter.addEventListener('change', () => {
        loadMovies(genreFilter.value, sortFilter.value);
        window.history.pushState({}, '', `?genre=${genreFilter.value}&sort=${sortFilter.value}`);
    });
}

if (sortFilter) {
    sortFilter.addEventListener('change', () => {
        loadMovies(genreFilter.value, sortFilter.value);
        window.history.pushState({}, '', `?genre=${genreFilter.value}&sort=${sortFilter.value}`);
    });
}

const compareForm = document.querySelector('.compare-form');
if (compareForm) {
    compareForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const compareId = compareForm.querySelector('input[name="compare_id"]').value;
        window.location.href = `movie.php?id=${window.location.search.match(/id=([^&]+)/)[1]}&compare=${compareId}`;
    });
}

loadCarousel();
loadRecommendations();
loadMovies(genreFilter ? genreFilter.value : '', sortFilter ? sortFilter.value : 'year_desc');
